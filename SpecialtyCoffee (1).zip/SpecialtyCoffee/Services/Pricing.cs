namespace SpecialtyCoffee.Services;

public static class Pricing
{
    public const string Currency = "ر.س";
    public const decimal FreeShippingThreshold = 200m;
    public const decimal ShippingFee = 25m;

    /// <summary>الشحن مجاني للطلبات 200 ر.س فأكثر</summary>
    public static decimal Shipping(decimal subtotal) =>
        subtotal <= 0 || subtotal >= FreeShippingThreshold ? 0m : ShippingFee;
}
