using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using SpecialtyCoffee.Data;
using SpecialtyCoffee.Models;

namespace SpecialtyCoffee.Services;

public class CartLine
{
    public Product Product { get; init; } = null!;
    public int Quantity { get; init; }
    public decimal LineTotal => Product.Price * Quantity;
}

/// <summary>
/// سلة التسوق: نخزّن في الـ Session فقط (رقم المنتج → الكمية)،
/// ونقرأ الأسعار والمخزون من قاعدة البيانات في كل مرة لضمان الدقة.
/// </summary>
public class CartService
{
    private const string SessionKey = "cart";

    private readonly IHttpContextAccessor _http;
    private readonly ApplicationDbContext _db;

    public CartService(IHttpContextAccessor http, ApplicationDbContext db)
    {
        _http = http;
        _db = db;
    }

    private ISession Session => _http.HttpContext!.Session;

    private Dictionary<int, int> Read()
    {
        var json = Session.GetString(SessionKey);
        if (string.IsNullOrEmpty(json))
        {
            return new Dictionary<int, int>();
        }

        return JsonSerializer.Deserialize<Dictionary<int, int>>(json) ?? new Dictionary<int, int>();
    }

    private void Write(Dictionary<int, int> cart) =>
        Session.SetString(SessionKey, JsonSerializer.Serialize(cart));

    /// <summary>إجمالي عدد القطع في السلة (للشارة في الشريط العلوي)</summary>
    public int Count => Read().Values.Sum();

    public int GetQuantity(int productId) => Read().GetValueOrDefault(productId);

    public void Add(int productId, int quantity)
    {
        var cart = Read();
        cart[productId] = cart.GetValueOrDefault(productId) + quantity;
        Write(cart);
    }

    public void SetQuantity(int productId, int quantity)
    {
        var cart = Read();
        if (quantity <= 0)
        {
            cart.Remove(productId);
        }
        else
        {
            cart[productId] = quantity;
        }

        Write(cart);
    }

    public void Remove(int productId)
    {
        var cart = Read();
        cart.Remove(productId);
        Write(cart);
    }

    public void Clear() => Session.Remove(SessionKey);

    public async Task<List<CartLine>> GetLinesAsync()
    {
        var cart = Read();
        if (cart.Count == 0)
        {
            return new List<CartLine>();
        }

        var ids = cart.Keys.ToList();
        var products = await _db.Products
            .AsNoTracking()
            .Where(p => ids.Contains(p.Id) && p.IsActive)
            .ToListAsync();

        return products
            .Select(p => new CartLine
            {
                Product = p,
                Quantity = Math.Min(cart[p.Id], p.StockQuantity)
            })
            .Where(l => l.Quantity > 0)
            .OrderBy(l => l.Product.Name)
            .ToList();
    }
}
