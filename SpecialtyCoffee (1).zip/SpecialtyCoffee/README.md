# متجر القهوة المختصة (Specialty Coffee E-commerce)

متجر إلكتروني متكامل لبيع أدوات القهوة المختصة وحبوبها، مبني بـ **ASP.NET Core 8 MVC** و**SQL Server** و**ASP.NET Core Identity**، بواجهة عربية (RTL).

## المزايا

**المتجر (للعملاء)**
- عرض المنتجات مع فلترة حسب: النوع (أدوات / حبوب)، نطاق السعر، التقييم، بحث نصي، وترتيب وتقسيم صفحات.
- صفحة تفاصيل المنتج وتقييمات العملاء (تقييم واحد لكل مستخدم، قابل للتعديل).
- سلة تسوق (تُحفظ في الـ Session) مع تحديث الكميات والتحقق من المخزون.
- إتمام الطلب (Checkout) يتطلب تسجيل الدخول، مع **محاكاة دفع**:
  - بطاقة بنكية (تحقق Luhn + تاريخ الانتهاء + CVV) أو الدفع عند الاستلام.
  - لا تُحفظ بيانات البطاقة أبداً، يُحفظ مرجع الدفع (آخر 4 أرقام) فقط.
  - الطلب وخصم المخزون يتمان داخل معاملة (Transaction) واحدة مع حماية من التعارض (RowVersion).
- صفحة «طلباتي» وتفاصيل كل طلب (للمالك فقط).

**لوحة تحكم المدير** (`/Admin`، دور `Admin`)
- نظرة عامة: المبيعات، عدد الطلبات، تنبيهات المخزون المنخفض، أحدث الطلبات.
- إدارة المنتجات: إضافة، تعديل، حذف (المنتج المرتبط بطلبات سابقة يُخفى بدل الحذف)، وتعديل سريع للمخزون.
- إدارة الطلبات: فلترة بالحالة، تفاصيل الطلب، تغيير الحالة، وإرجاع المخزون تلقائياً عند الإلغاء.

## المتطلبات
- [.NET 8 SDK](https://dotnet.microsoft.com/download/dotnet/8.0)
- SQL Server (LocalDB يأتي مع Visual Studio على Windows، أو SQL Server Express / Docker)

## التشغيل

```bash
cd SpecialtyCoffee
dotnet restore
dotnet run
```

ثم افتح: `https://localhost:7080`

عند أول تشغيل تُنشأ قاعدة البيانات `SpecialtyCoffeeDb` تلقائياً مع 14 منتجاً تجريبياً وحساب المدير.

### حساب المدير الافتراضي
| البريد | كلمة المرور |
|---|---|
| `admin@coffee.com` | `Admin@123` |

يمكن تغييرهما من القسم `SeedAdmin` في `appsettings.json` **قبل أول تشغيل**. غيّر كلمة المرور عند أي استخدام خارج بيئة التطوير.

### تجربة الدفع (محاكاة)
| الرقم | النتيجة |
|---|---|
| `4242 4242 4242 4242` | نجاح |
| `4000 0002 0000 0000` | رفض البطاقة |

(تاريخ انتهاء مستقبلي مثل `12/30` وأي CVV من 3 أرقام.)

## إعداد قاعدة البيانات

سلسلة الاتصال الافتراضية (LocalDB على Windows) في `appsettings.json`.

لـ SQL Server عبر Docker أو غيره، غيّرها مثلاً إلى:
```
Server=localhost,1433;Database=SpecialtyCoffeeDb;User Id=sa;Password=YourStrong!Passw0rd;TrustServerCertificate=True
```

### الانتقال إلى Migrations (اختياري)
المشروع يستخدم `EnsureCreated()` للتبسيط. لاستخدام Migrations بدلاً منه:
```bash
dotnet tool install --global dotnet-ef
dotnet ef migrations add InitialCreate
```
ثم في `Data/SeedData.cs` استبدل `EnsureCreatedAsync()` بـ `MigrateAsync()`.
(إن كانت قاعدة البيانات موجودة مسبقاً من `EnsureCreated` فاحذفها أولاً: `dotnet ef database drop`.)

## هيكل المشروع

```
SpecialtyCoffee/
├── Program.cs                 إعداد الخدمات، Identity، Session، المسارات
├── Data/                      DbContext + بيانات أولية (SeedData)
├── Models/                    Product, Review, Order, OrderItem, Enums
├── Services/                  CartService (سلة الـ Session) + Pricing (الشحن)
├── ViewModels/                نماذج العرض للمتجر ولوحة التحكم
├── Controllers/               Home, Products, Cart, Checkout, Orders
├── Areas/Admin/               Dashboard, Products, Orders (+ Views)
├── Areas/Identity/Pages/      ربط صفحات Identity الجاهزة بتخطيط الموقع
├── Views/                     واجهات المتجر
└── wwwroot/css/site.css
```

## ملاحظات
- الأرقام والتواريخ تُعرض بثقافة `en-US` (ضبطت في `Program.cs`) لتجنّب التقويم الهجري والأرقام الهندية.
- صفحات تسجيل الدخول والتسجيل هي صفحات Identity الجاهزة (باللغة الإنجليزية) وتظهر داخل تخطيط الموقع.
- الصور: المنتجات التجريبية بدون صور وتظهر أيقونة افتراضية. أضف رابط صورة من لوحة التحكم.
- الشحن مجاني للطلبات 200 ر.س فأكثر، وإلا 25 ر.س (قابل للتعديل في `Services/Pricing.cs`).

## أفكار للتطوير
- رفع الصور للمنتجات بدل الرابط، وإضافة تصنيفات كجدول مستقل.
- بوابة دفع حقيقية (Stripe / Moyasar / HyperPay) بدل المحاكاة.
- إرسال بريد تأكيد الطلب، وتعريب صفحات Identity.
- اختبارات وحدة لمنطق الطلب والمخزون.
