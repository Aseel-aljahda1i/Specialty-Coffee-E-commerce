using System.ComponentModel.DataAnnotations;
using SpecialtyCoffee.Models;
using SpecialtyCoffee.Services;

namespace SpecialtyCoffee.ViewModels;

public class ProductListViewModel
{
    public List<Product> Products { get; set; } = new();

    public ProductType? Type { get; set; }
    public decimal? MinPrice { get; set; }
    public decimal? MaxPrice { get; set; }
    public double? MinRating { get; set; }
    public string? Q { get; set; }
    public string Sort { get; set; } = "newest";

    public int Page { get; set; } = 1;
    public int TotalPages { get; set; } = 1;
    public int TotalCount { get; set; }
}

public class ProductDetailsViewModel
{
    public Product Product { get; set; } = null!;
    public List<Review> Reviews { get; set; } = new();
    public Review? MyReview { get; set; }
    public int InCart { get; set; }
}

public class CartViewModel
{
    public List<CartLine> Lines { get; set; } = new();
    public decimal Subtotal => Lines.Sum(l => l.LineTotal);
    public decimal Shipping => Pricing.Shipping(Subtotal);
    public decimal Total => Subtotal + Shipping;
}

public class CheckoutViewModel
{
    [Required(ErrorMessage = "الاسم الكامل مطلوب")]
    [StringLength(100)]
    [Display(Name = "الاسم الكامل")]
    public string FullName { get; set; } = string.Empty;

    [Required(ErrorMessage = "رقم الجوال مطلوب")]
    [RegularExpression(@"^[0-9+\s-]{9,15}$", ErrorMessage = "رقم الجوال غير صحيح")]
    [Display(Name = "رقم الجوال")]
    public string Phone { get; set; } = string.Empty;

    [Required(ErrorMessage = "المدينة مطلوبة")]
    [StringLength(60)]
    [Display(Name = "المدينة")]
    public string City { get; set; } = string.Empty;

    [Required(ErrorMessage = "العنوان مطلوب")]
    [StringLength(300)]
    [Display(Name = "العنوان التفصيلي")]
    public string Address { get; set; } = string.Empty;

    [StringLength(500)]
    [Display(Name = "ملاحظات (اختياري)")]
    public string? Notes { get; set; }

    [Display(Name = "طريقة الدفع")]
    public PaymentMethod PaymentMethod { get; set; } = PaymentMethod.Card;

    // بيانات البطاقة: تُستخدم للمحاكاة فقط ولا يتم حفظها أبداً
    [Display(Name = "اسم حامل البطاقة")]
    public string? CardHolder { get; set; }

    [Display(Name = "رقم البطاقة")]
    public string? CardNumber { get; set; }

    [Display(Name = "تاريخ الانتهاء")]
    public string? Expiry { get; set; }

    [Display(Name = "CVV")]
    public string? Cvv { get; set; }

    // للعرض فقط
    public List<CartLine> Lines { get; set; } = new();
    public decimal Subtotal => Lines.Sum(l => l.LineTotal);
    public decimal Shipping => Pricing.Shipping(Subtotal);
    public decimal Total => Subtotal + Shipping;
}
