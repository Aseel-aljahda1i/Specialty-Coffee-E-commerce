using System.ComponentModel.DataAnnotations;
using SpecialtyCoffee.Models;

namespace SpecialtyCoffee.ViewModels;

public class DashboardViewModel
{
    public int TotalProducts { get; set; }
    public int ActiveProducts { get; set; }
    public int LowStockCount { get; set; }
    public int TotalOrders { get; set; }
    public int PendingOrders { get; set; }
    public decimal Revenue { get; set; }
    public List<Order> RecentOrders { get; set; } = new();
    public List<Product> LowStockProducts { get; set; } = new();
}

public class ProductFormViewModel
{
    public int Id { get; set; }

    [Required(ErrorMessage = "اسم المنتج مطلوب")]
    [StringLength(120)]
    [Display(Name = "اسم المنتج")]
    public string Name { get; set; } = string.Empty;

    [StringLength(2000)]
    [Display(Name = "الوصف")]
    public string? Description { get; set; }

    [Range(0.01, 100000, ErrorMessage = "السعر يجب أن يكون أكبر من صفر")]
    [Display(Name = "السعر (ر.س)")]
    public decimal Price { get; set; }

    [Display(Name = "النوع")]
    public ProductType Type { get; set; } = ProductType.Tool;

    [StringLength(60)]
    [Display(Name = "التصنيف الفرعي")]
    public string? SubCategory { get; set; }

    [StringLength(500)]
    [Url(ErrorMessage = "الرابط غير صحيح")]
    [Display(Name = "رابط الصورة")]
    public string? ImageUrl { get; set; }

    [Range(0, 100000, ErrorMessage = "الكمية غير صحيحة")]
    [Display(Name = "الكمية في المخزون")]
    public int StockQuantity { get; set; }

    [Display(Name = "ظاهر في المتجر")]
    public bool IsActive { get; set; } = true;
}
