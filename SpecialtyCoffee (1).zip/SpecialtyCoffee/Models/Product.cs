using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SpecialtyCoffee.Models;

public class Product
{
    public int Id { get; set; }

    [Required, StringLength(120)]
    public string Name { get; set; } = string.Empty;

    [StringLength(2000)]
    public string? Description { get; set; }

    [Column(TypeName = "decimal(18,2)")]
    public decimal Price { get; set; }

    public ProductType Type { get; set; }

    /// <summary>تصنيف فرعي مثل: أقماع تقطير، مطاحن، موازين...</summary>
    [StringLength(60)]
    public string? SubCategory { get; set; }

    [StringLength(500)]
    public string? ImageUrl { get; set; }

    public int StockQuantity { get; set; }

    /// <summary>متوسط التقييم (0 - 5)</summary>
    public double Rating { get; set; }

    public int RatingCount { get; set; }

    public bool IsActive { get; set; } = true;

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    /// <summary>لمنع تعارض التعديلات المتزامنة على المخزون</summary>
    [Timestamp]
    public byte[]? RowVersion { get; set; }

    public List<Review> Reviews { get; set; } = new();
}
