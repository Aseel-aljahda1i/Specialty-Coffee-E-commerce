namespace SpecialtyCoffee.Models;

public enum ProductType
{
    Tool = 1,
    Beans = 2
}

public enum OrderStatus
{
    Pending = 1,
    Paid = 2,
    Processing = 3,
    Shipped = 4,
    Delivered = 5,
    Cancelled = 6
}

public enum PaymentMethod
{
    Card = 1,
    CashOnDelivery = 2
}

public static class EnumExtensions
{
    public static string ToArabic(this ProductType type) => type switch
    {
        ProductType.Tool => "أدوات",
        ProductType.Beans => "حبوب",
        _ => type.ToString()
    };

    public static string ToArabic(this OrderStatus status) => status switch
    {
        OrderStatus.Pending => "قيد الانتظار",
        OrderStatus.Paid => "مدفوع",
        OrderStatus.Processing => "قيد التجهيز",
        OrderStatus.Shipped => "تم الشحن",
        OrderStatus.Delivered => "تم التسليم",
        OrderStatus.Cancelled => "ملغي",
        _ => status.ToString()
    };

    public static string BadgeClass(this OrderStatus status) => status switch
    {
        OrderStatus.Pending => "text-bg-warning",
        OrderStatus.Paid => "text-bg-info",
        OrderStatus.Processing => "text-bg-primary",
        OrderStatus.Shipped => "text-bg-secondary",
        OrderStatus.Delivered => "text-bg-success",
        OrderStatus.Cancelled => "text-bg-danger",
        _ => "text-bg-light"
    };

    public static string ToArabic(this PaymentMethod method) => method switch
    {
        PaymentMethod.Card => "بطاقة بنكية (محاكاة)",
        PaymentMethod.CashOnDelivery => "الدفع عند الاستلام",
        _ => method.ToString()
    };
}
