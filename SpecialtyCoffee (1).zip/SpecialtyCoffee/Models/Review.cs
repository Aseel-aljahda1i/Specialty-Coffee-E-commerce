using System.ComponentModel.DataAnnotations;

namespace SpecialtyCoffee.Models;

public class Review
{
    public int Id { get; set; }

    public int ProductId { get; set; }
    public Product? Product { get; set; }

    [Required]
    public string UserId { get; set; } = string.Empty;

    [StringLength(100)]
    public string UserDisplayName { get; set; } = string.Empty;

    [Range(1, 5)]
    public int Stars { get; set; }

    [StringLength(500)]
    public string? Comment { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}
