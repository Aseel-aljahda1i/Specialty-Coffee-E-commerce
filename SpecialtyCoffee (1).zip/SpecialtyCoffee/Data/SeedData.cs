using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using SpecialtyCoffee.Models;

namespace SpecialtyCoffee.Data;

public static class SeedData
{
    public const string AdminRole = "Admin";

    public static async Task InitializeAsync(IServiceProvider services)
    {
        var db = services.GetRequiredService<ApplicationDbContext>();
        var config = services.GetRequiredService<IConfiguration>();

        // ملاحظة: EnsureCreated مناسب للمشاريع الدراسية. للإنتاج استخدم Migrations (راجع README).
        await db.Database.EnsureCreatedAsync();

        await SeedAdminAsync(services, config);

        if (!await db.Products.AnyAsync())
        {
            db.Products.AddRange(BuildProducts());
            await db.SaveChangesAsync();
        }
    }

    private static async Task SeedAdminAsync(IServiceProvider services, IConfiguration config)
    {
        var roleManager = services.GetRequiredService<RoleManager<IdentityRole>>();
        var userManager = services.GetRequiredService<UserManager<IdentityUser>>();

        if (!await roleManager.RoleExistsAsync(AdminRole))
        {
            await roleManager.CreateAsync(new IdentityRole(AdminRole));
        }

        var email = config["SeedAdmin:Email"] ?? "admin@coffee.com";
        var password = config["SeedAdmin:Password"] ?? "Admin@123";

        var admin = await userManager.FindByEmailAsync(email);
        if (admin == null)
        {
            admin = new IdentityUser
            {
                UserName = email,
                Email = email,
                EmailConfirmed = true
            };

            var result = await userManager.CreateAsync(admin, password);
            if (!result.Succeeded)
            {
                throw new InvalidOperationException(
                    "Failed to create admin user: " + string.Join("; ", result.Errors.Select(e => e.Description)));
            }
        }

        if (!await userManager.IsInRoleAsync(admin, AdminRole))
        {
            await userManager.AddToRoleAsync(admin, AdminRole);
        }
    }

    private static List<Product> BuildProducts() => new()
    {
        // ---------- أدوات ----------
        new Product
        {
            Name = "قمع تقطير سيراميك (V60) مقاس 02",
            Description = "قمع مخروطي من السيراميك بخطوط حلزونية داخلية تمنح استخلاصاً متوازناً. يناسب كوباً إلى أربعة أكواب.",
            Price = 89m, Type = ProductType.Tool, SubCategory = "أقماع تقطير",
            StockQuantity = 25, Rating = 4.8, RatingCount = 124
        },
        new Product
        {
            Name = "قمع تقطير ستانلس ستيل بفلتر دائم",
            Description = "قمع من الستانلس ستيل بفلتر معدني دقيق قابل لإعادة الاستخدام، يعطي قهوة غنية بالزيوت.",
            Price = 119m, Type = ProductType.Tool, SubCategory = "أقماع تقطير",
            StockQuantity = 14, Rating = 4.4, RatingCount = 58
        },
        new Product
        {
            Name = "فلاتر ورقية للتقطير (100 حبة)",
            Description = "فلاتر ورقية مبيّضة بدون أكسجين لا تؤثر على نكهة القهوة. مقاس 02.",
            Price = 24m, Type = ProductType.Tool, SubCategory = "ملحقات",
            StockQuantity = 120, Rating = 4.7, RatingCount = 201
        },
        new Product
        {
            Name = "مطحنة يدوية بشفرات مخروطية",
            Description = "مطحنة يدوية بجسم ألمنيوم وشفرات مخروطية من الستانلس ستيل مع 30 درجة طحن قابلة للضبط.",
            Price = 249m, Type = ProductType.Tool, SubCategory = "مطاحن",
            StockQuantity = 9, Rating = 4.9, RatingCount = 87
        },
        new Product
        {
            Name = "مطحنة كهربائية بشفرات مخروطية",
            Description = "مطحنة كهربائية هادئة بـ 40 درجة طحن وحاوية للحبوب بسعة 250 غرام. مناسبة للتقطير والإسبريسو.",
            Price = 649m, Type = ProductType.Tool, SubCategory = "مطاحن",
            StockQuantity = 6, Rating = 4.6, RatingCount = 43
        },
        new Product
        {
            Name = "ميزان قهوة رقمي بمؤقت (0.1 غ)",
            Description = "ميزان دقيق بحساسية 0.1 غرام ومؤقت مدمج وسطح مقاوم للماء. ضروري لتحضير ثابت الجودة.",
            Price = 139m, Type = ProductType.Tool, SubCategory = "موازين",
            StockQuantity = 18, Rating = 4.5, RatingCount = 96
        },
        new Product
        {
            Name = "غلاية بعنق الإوزة 0.9 لتر مع ضبط الحرارة",
            Description = "غلاية كهربائية بعنق منحنٍ لتحكم دقيق بالصب، مع ضبط حرارة من 40 إلى 100 مئوية.",
            Price = 389m, Type = ProductType.Tool, SubCategory = "أباريق وغلايات",
            StockQuantity = 4, Rating = 4.7, RatingCount = 61
        },
        new Product
        {
            Name = "إبريق فرنش برس زجاجي 600 مل",
            Description = "إبريق بإطار ستانلس ستيل ومكبس بفلتر مزدوج لتحضير قهوة كاملة الجسم بسهولة.",
            Price = 79m, Type = ProductType.Tool, SubCategory = "ملحقات",
            StockQuantity = 30, Rating = 4.2, RatingCount = 72
        },

        // ---------- حبوب ----------
        new Product
        {
            Name = "إثيوبيا يرغاتشيف - تحميص فاتح (250 غ)",
            Description = "حبوب أحادية المنشأ بنكهات زهرية وحمضيات وتوت أزرق. مناسبة للتقطير.",
            Price = 68m, Type = ProductType.Beans, SubCategory = "أحادية المنشأ",
            StockQuantity = 40, Rating = 4.9, RatingCount = 156
        },
        new Product
        {
            Name = "كولومبيا هويلا - تحميص متوسط (250 غ)",
            Description = "قوام متوازن بنكهات كراميل وتفاح أحمر وحموضة ناعمة. تصلح للتقطير والإسبريسو.",
            Price = 59m, Type = ProductType.Beans, SubCategory = "أحادية المنشأ",
            StockQuantity = 55, Rating = 4.6, RatingCount = 110
        },
        new Product
        {
            Name = "كينيا AA - تحميص فاتح إلى متوسط (250 غ)",
            Description = "حموضة لامعة بنكهات توت أسود وطماطم حلوة وسكر قصب. لعشّاق القهوة الفاكهية.",
            Price = 72m, Type = ProductType.Beans, SubCategory = "أحادية المنشأ",
            StockQuantity = 3, Rating = 4.7, RatingCount = 64
        },
        new Product
        {
            Name = "البرازيل سانتوس - تحميص متوسط غامق (250 غ)",
            Description = "جسم ممتلئ ونكهات شوكولاتة ومكسرات وحموضة منخفضة. مثالية للحليب.",
            Price = 49m, Type = ProductType.Beans, SubCategory = "أحادية المنشأ",
            StockQuantity = 70, Rating = 4.1, RatingCount = 88
        },
        new Product
        {
            Name = "بلند إسبريسو البيت (1 كغ)",
            Description = "مزيج من البرازيل وكولومبيا وإثيوبيا بتحميص متوسط، يعطي كريما كثيفة ونكهات شوكولاتة داكنة.",
            Price = 160m, Type = ProductType.Beans, SubCategory = "بلندات",
            StockQuantity = 22, Rating = 4.5, RatingCount = 133
        },
        new Product
        {
            Name = "بلند التقطير الصباحي (250 غ)",
            Description = "بلند خفيف الجسم بنكهات عسل وبرتقال وزهر، مصمم ليكون كوب الصباح المثالي.",
            Price = 55m, Type = ProductType.Beans, SubCategory = "بلندات",
            StockQuantity = 0, Rating = 4.3, RatingCount = 39
        }
    };
}
