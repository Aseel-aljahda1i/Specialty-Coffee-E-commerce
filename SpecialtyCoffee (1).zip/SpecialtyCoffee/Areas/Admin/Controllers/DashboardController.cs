using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SpecialtyCoffee.Data;
using SpecialtyCoffee.Models;
using SpecialtyCoffee.ViewModels;

namespace SpecialtyCoffee.Areas.Admin.Controllers;

[Area("Admin")]
[Authorize(Roles = SeedData.AdminRole)]
public class DashboardController : Controller
{
    public const int LowStockThreshold = 5;

    private readonly ApplicationDbContext _db;

    public DashboardController(ApplicationDbContext db)
    {
        _db = db;
    }

    public async Task<IActionResult> Index()
    {
        var revenue = await _db.Orders
            .Where(o => o.Status != OrderStatus.Cancelled)
            .Select(o => (decimal?)o.Total)
            .SumAsync() ?? 0m;

        var vm = new DashboardViewModel
        {
            TotalProducts = await _db.Products.CountAsync(),
            ActiveProducts = await _db.Products.CountAsync(p => p.IsActive),
            LowStockCount = await _db.Products.CountAsync(p => p.IsActive && p.StockQuantity <= LowStockThreshold),
            TotalOrders = await _db.Orders.CountAsync(),
            PendingOrders = await _db.Orders.CountAsync(o => o.Status == OrderStatus.Pending || o.Status == OrderStatus.Paid),
            Revenue = revenue,
            RecentOrders = await _db.Orders
                .AsNoTracking()
                .OrderByDescending(o => o.CreatedAt)
                .Take(8)
                .ToListAsync(),
            LowStockProducts = await _db.Products
                .AsNoTracking()
                .Where(p => p.IsActive && p.StockQuantity <= LowStockThreshold)
                .OrderBy(p => p.StockQuantity)
                .Take(8)
                .ToListAsync()
        };

        return View(vm);
    }
}
