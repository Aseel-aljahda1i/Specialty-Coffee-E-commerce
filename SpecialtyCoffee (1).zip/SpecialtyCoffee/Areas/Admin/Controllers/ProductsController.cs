using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SpecialtyCoffee.Data;
using SpecialtyCoffee.Models;
using SpecialtyCoffee.ViewModels;

namespace SpecialtyCoffee.Areas.Admin.Controllers;

[Area("Admin")]
[Authorize(Roles = SeedData.AdminRole)]
public class ProductsController : Controller
{
    private readonly ApplicationDbContext _db;

    public ProductsController(ApplicationDbContext db)
    {
        _db = db;
    }

    public async Task<IActionResult> Index(string? q, bool lowStock = false)
    {
        var query = _db.Products.AsNoTracking().AsQueryable();

        if (!string.IsNullOrWhiteSpace(q))
        {
            var term = q.Trim();
            query = query.Where(p => p.Name.Contains(term) || (p.SubCategory != null && p.SubCategory.Contains(term)));
        }

        if (lowStock)
        {
            query = query.Where(p => p.StockQuantity <= DashboardController.LowStockThreshold);
        }

        ViewData["Q"] = q;
        ViewData["LowStock"] = lowStock;

        var products = await query.OrderByDescending(p => p.Id).ToListAsync();
        return View(products);
    }

    public IActionResult Create() => View(new ProductFormViewModel());

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(ProductFormViewModel vm)
    {
        if (!ModelState.IsValid)
        {
            return View(vm);
        }

        var product = new Product { CreatedAt = DateTime.UtcNow };
        Apply(product, vm);

        _db.Products.Add(product);
        await _db.SaveChangesAsync();

        TempData["Success"] = $"تمت إضافة المنتج «{product.Name}».";
        return RedirectToAction(nameof(Index));
    }

    public async Task<IActionResult> Edit(int id)
    {
        var product = await _db.Products.AsNoTracking().FirstOrDefaultAsync(p => p.Id == id);
        if (product == null)
        {
            return NotFound();
        }

        return View(new ProductFormViewModel
        {
            Id = product.Id,
            Name = product.Name,
            Description = product.Description,
            Price = product.Price,
            Type = product.Type,
            SubCategory = product.SubCategory,
            ImageUrl = product.ImageUrl,
            StockQuantity = product.StockQuantity,
            IsActive = product.IsActive
        });
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, ProductFormViewModel vm)
    {
        if (id != vm.Id)
        {
            return BadRequest();
        }

        if (!ModelState.IsValid)
        {
            return View(vm);
        }

        var product = await _db.Products.FirstOrDefaultAsync(p => p.Id == id);
        if (product == null)
        {
            return NotFound();
        }

        Apply(product, vm);

        try
        {
            await _db.SaveChangesAsync();
        }
        catch (DbUpdateConcurrencyException)
        {
            ModelState.AddModelError(string.Empty, "تم تعديل هذا المنتج (أو مخزونه) من جهة أخرى أثناء التعديل. أعد تحميل الصفحة وحاول مجدداً.");
            return View(vm);
        }

        TempData["Success"] = $"تم حفظ تعديلات «{product.Name}».";
        return RedirectToAction(nameof(Index));
    }

    // تعديل سريع للمخزون من جدول المنتجات
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> UpdateStock(int id, int quantity)
    {
        var product = await _db.Products.FirstOrDefaultAsync(p => p.Id == id);
        if (product == null)
        {
            return NotFound();
        }

        if (quantity < 0)
        {
            TempData["Error"] = "الكمية لا يمكن أن تكون سالبة.";
            return RedirectToAction(nameof(Index));
        }

        product.StockQuantity = quantity;

        try
        {
            await _db.SaveChangesAsync();
            TempData["Success"] = $"تم تحديث مخزون «{product.Name}» إلى {quantity}.";
        }
        catch (DbUpdateConcurrencyException)
        {
            TempData["Error"] = "تغيّر المخزون أثناء التحديث (ربما بسبب طلب جديد). حاول مرة أخرى.";
        }

        return RedirectToAction(nameof(Index));
    }

    public async Task<IActionResult> Delete(int id)
    {
        var product = await _db.Products.AsNoTracking().FirstOrDefaultAsync(p => p.Id == id);
        if (product == null)
        {
            return NotFound();
        }

        ViewData["HasOrders"] = await _db.OrderItems.AnyAsync(i => i.ProductId == id);
        return View(product);
    }

    [HttpPost, ActionName("Delete")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        var product = await _db.Products.FirstOrDefaultAsync(p => p.Id == id);
        if (product == null)
        {
            return NotFound();
        }

        var hasOrders = await _db.OrderItems.AnyAsync(i => i.ProductId == id);
        if (hasOrders)
        {
            // المنتج مرتبط بطلبات سابقة: نخفيه فقط للحفاظ على سجل الطلبات
            product.IsActive = false;
            TempData["Success"] = $"«{product.Name}» مرتبط بطلبات سابقة، لذلك تم إخفاؤه من المتجر بدلاً من حذفه.";
        }
        else
        {
            _db.Products.Remove(product);
            TempData["Success"] = $"تم حذف «{product.Name}».";
        }

        await _db.SaveChangesAsync();
        return RedirectToAction(nameof(Index));
    }

    private static void Apply(Product product, ProductFormViewModel vm)
    {
        product.Name = vm.Name.Trim();
        product.Description = string.IsNullOrWhiteSpace(vm.Description) ? null : vm.Description.Trim();
        product.Price = vm.Price;
        product.Type = vm.Type;
        product.SubCategory = string.IsNullOrWhiteSpace(vm.SubCategory) ? null : vm.SubCategory.Trim();
        product.ImageUrl = string.IsNullOrWhiteSpace(vm.ImageUrl) ? null : vm.ImageUrl.Trim();
        product.StockQuantity = vm.StockQuantity;
        product.IsActive = vm.IsActive;
    }
}
