using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SpecialtyCoffee.Data;
using SpecialtyCoffee.Models;

namespace SpecialtyCoffee.Areas.Admin.Controllers;

[Area("Admin")]
[Authorize(Roles = SeedData.AdminRole)]
public class OrdersController : Controller
{
    private readonly ApplicationDbContext _db;

    public OrdersController(ApplicationDbContext db)
    {
        _db = db;
    }

    public async Task<IActionResult> Index(OrderStatus? status)
    {
        var query = _db.Orders.AsNoTracking().Include(o => o.Items).AsQueryable();

        if (status.HasValue)
        {
            var s = status.Value;
            query = query.Where(o => o.Status == s);
        }

        ViewData["Status"] = status;

        var orders = await query.OrderByDescending(o => o.CreatedAt).ToListAsync();
        return View(orders);
    }

    public async Task<IActionResult> Details(int id)
    {
        var order = await _db.Orders
            .AsNoTracking()
            .Include(o => o.Items)
            .Include(o => o.User)
            .FirstOrDefaultAsync(o => o.Id == id);

        if (order == null)
        {
            return NotFound();
        }

        return View(order);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> UpdateStatus(int id, OrderStatus status)
    {
        var order = await _db.Orders.Include(o => o.Items).FirstOrDefaultAsync(o => o.Id == id);
        if (order == null)
        {
            return NotFound();
        }

        if (order.Status == OrderStatus.Cancelled)
        {
            TempData["Error"] = "لا يمكن تغيير حالة طلب ملغي.";
            return RedirectToAction(nameof(Details), new { id });
        }

        if (status == OrderStatus.Cancelled)
        {
            // إرجاع الكميات إلى المخزون عند الإلغاء
            var productIds = order.Items.Select(i => i.ProductId).ToList();
            var products = await _db.Products.Where(p => productIds.Contains(p.Id)).ToListAsync();

            foreach (var item in order.Items)
            {
                var product = products.FirstOrDefault(p => p.Id == item.ProductId);
                if (product != null)
                {
                    product.StockQuantity += item.Quantity;
                }
            }
        }

        order.Status = status;

        try
        {
            await _db.SaveChangesAsync();
            TempData["Success"] = $"تم تحديث حالة الطلب #{order.Id} إلى «{status.ToArabic()}».";
        }
        catch (DbUpdateConcurrencyException)
        {
            TempData["Error"] = "تغيّر المخزون أثناء التحديث. حاول مرة أخرى.";
        }

        return RedirectToAction(nameof(Details), new { id });
    }
}
