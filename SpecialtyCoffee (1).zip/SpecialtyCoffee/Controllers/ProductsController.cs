using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SpecialtyCoffee.Data;
using SpecialtyCoffee.Models;
using SpecialtyCoffee.Services;
using SpecialtyCoffee.ViewModels;

namespace SpecialtyCoffee.Controllers;

public class ProductsController : Controller
{
    private const int PageSize = 9;

    private readonly ApplicationDbContext _db;
    private readonly UserManager<IdentityUser> _userManager;
    private readonly CartService _cart;

    public ProductsController(ApplicationDbContext db, UserManager<IdentityUser> userManager, CartService cart)
    {
        _db = db;
        _userManager = userManager;
        _cart = cart;
    }

    // GET: /Products?type=1&minPrice=50&maxPrice=300&minRating=4&q=...&sort=price_asc&page=1
    public async Task<IActionResult> Index(
        ProductType? type, decimal? minPrice, decimal? maxPrice, double? minRating,
        string? q, string sort = "newest", int page = 1)
    {
        var query = _db.Products.AsNoTracking().Where(p => p.IsActive);

        if (type.HasValue)
        {
            var t = type.Value;
            query = query.Where(p => p.Type == t);
        }

        if (minPrice.HasValue)
        {
            query = query.Where(p => p.Price >= minPrice.Value);
        }

        if (maxPrice.HasValue)
        {
            query = query.Where(p => p.Price <= maxPrice.Value);
        }

        if (minRating.HasValue)
        {
            query = query.Where(p => p.Rating >= minRating.Value);
        }

        if (!string.IsNullOrWhiteSpace(q))
        {
            var term = q.Trim();
            query = query.Where(p => p.Name.Contains(term)
                                     || (p.Description != null && p.Description.Contains(term))
                                     || (p.SubCategory != null && p.SubCategory.Contains(term)));
        }

        query = sort switch
        {
            "price_asc" => query.OrderBy(p => p.Price),
            "price_desc" => query.OrderByDescending(p => p.Price),
            "rating" => query.OrderByDescending(p => p.Rating).ThenByDescending(p => p.RatingCount),
            _ => query.OrderByDescending(p => p.CreatedAt).ThenByDescending(p => p.Id)
        };

        var total = await query.CountAsync();
        var totalPages = Math.Max(1, (int)Math.Ceiling(total / (double)PageSize));
        page = Math.Clamp(page, 1, totalPages);

        var products = await query
            .Skip((page - 1) * PageSize)
            .Take(PageSize)
            .ToListAsync();

        var vm = new ProductListViewModel
        {
            Products = products,
            Type = type,
            MinPrice = minPrice,
            MaxPrice = maxPrice,
            MinRating = minRating,
            Q = q,
            Sort = sort,
            Page = page,
            TotalPages = totalPages,
            TotalCount = total
        };

        return View(vm);
    }

    // GET: /Products/Details/5
    public async Task<IActionResult> Details(int id)
    {
        var product = await _db.Products
            .AsNoTracking()
            .FirstOrDefaultAsync(p => p.Id == id && p.IsActive);

        if (product == null)
        {
            return NotFound();
        }

        var reviews = await _db.Reviews
            .AsNoTracking()
            .Where(r => r.ProductId == id)
            .OrderByDescending(r => r.CreatedAt)
            .Take(20)
            .ToListAsync();

        Review? mine = null;
        var userId = _userManager.GetUserId(User);
        if (userId != null)
        {
            mine = await _db.Reviews.AsNoTracking()
                .FirstOrDefaultAsync(r => r.ProductId == id && r.UserId == userId);
        }

        return View(new ProductDetailsViewModel
        {
            Product = product,
            Reviews = reviews,
            MyReview = mine,
            InCart = _cart.GetQuantity(id)
        });
    }

    // POST: /Products/AddReview
    [Authorize]
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> AddReview(int id, int stars, string? comment)
    {
        var product = await _db.Products.FirstOrDefaultAsync(p => p.Id == id && p.IsActive);
        if (product == null)
        {
            return NotFound();
        }

        stars = Math.Clamp(stars, 1, 5);
        comment = string.IsNullOrWhiteSpace(comment) ? null : comment.Trim();
        if (comment is { Length: > 500 })
        {
            comment = comment[..500];
        }

        var userId = _userManager.GetUserId(User)!;
        var existing = await _db.Reviews.FirstOrDefaultAsync(r => r.ProductId == id && r.UserId == userId);

        // نحدّث المتوسط تراكمياً بدون المساس بالتقييمات الأولية للمنتج
        var sum = product.Rating * product.RatingCount;

        if (existing == null)
        {
            var displayName = User.Identity?.Name ?? "عميل";
            var at = displayName.IndexOf('@');
            if (at > 0)
            {
                displayName = displayName[..at];
            }

            _db.Reviews.Add(new Review
            {
                ProductId = id,
                UserId = userId,
                UserDisplayName = displayName,
                Stars = stars,
                Comment = comment
            });
            product.RatingCount += 1;
            sum += stars;
        }
        else
        {
            sum += stars - existing.Stars;
            existing.Stars = stars;
            existing.Comment = comment;
            existing.CreatedAt = DateTime.UtcNow;
        }

        product.Rating = product.RatingCount == 0 ? 0 : Math.Round(sum / product.RatingCount, 2);

        await _db.SaveChangesAsync();
        TempData["Success"] = "شكراً لتقييمك!";
        return RedirectToAction(nameof(Details), new { id });
    }
}
