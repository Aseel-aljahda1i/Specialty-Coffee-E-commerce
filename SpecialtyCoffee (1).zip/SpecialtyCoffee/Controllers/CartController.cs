using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SpecialtyCoffee.Data;
using SpecialtyCoffee.Services;
using SpecialtyCoffee.ViewModels;

namespace SpecialtyCoffee.Controllers;

public class CartController : Controller
{
    private readonly CartService _cart;
    private readonly ApplicationDbContext _db;

    public CartController(CartService cart, ApplicationDbContext db)
    {
        _cart = cart;
        _db = db;
    }

    public async Task<IActionResult> Index()
    {
        var vm = new CartViewModel { Lines = await _cart.GetLinesAsync() };
        return View(vm);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Add(int id, int quantity = 1, string? returnUrl = null)
    {
        var product = await _db.Products.AsNoTracking()
            .FirstOrDefaultAsync(p => p.Id == id && p.IsActive);

        if (product == null)
        {
            return NotFound();
        }

        quantity = Math.Max(1, quantity);
        var current = _cart.GetQuantity(id);
        var allowed = product.StockQuantity - current;

        if (allowed <= 0)
        {
            TempData["Error"] = $"لا توجد كمية إضافية متاحة من «{product.Name}».";
        }
        else
        {
            var toAdd = Math.Min(quantity, allowed);
            _cart.Add(id, toAdd);
            TempData["Success"] = toAdd < quantity
                ? $"تمت إضافة {toAdd} فقط من «{product.Name}» (الكمية المتاحة محدودة)."
                : $"تمت إضافة «{product.Name}» إلى السلة.";
        }

        if (!string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl))
        {
            return LocalRedirect(returnUrl);
        }

        return RedirectToAction(nameof(Index));
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Update(int id, int quantity)
    {
        var product = await _db.Products.AsNoTracking().FirstOrDefaultAsync(p => p.Id == id);
        if (product == null)
        {
            _cart.Remove(id);
            return RedirectToAction(nameof(Index));
        }

        if (quantity > product.StockQuantity)
        {
            quantity = product.StockQuantity;
            TempData["Error"] = $"أقصى كمية متاحة من «{product.Name}» هي {product.StockQuantity}.";
        }

        _cart.SetQuantity(id, quantity);
        return RedirectToAction(nameof(Index));
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Remove(int id)
    {
        _cart.Remove(id);
        return RedirectToAction(nameof(Index));
    }
}
