using System.Globalization;
using System.Text.RegularExpressions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SpecialtyCoffee.Data;
using SpecialtyCoffee.Models;
using SpecialtyCoffee.Services;
using SpecialtyCoffee.ViewModels;

namespace SpecialtyCoffee.Controllers;

[Authorize]
public class CheckoutController : Controller
{
    private readonly ApplicationDbContext _db;
    private readonly CartService _cart;
    private readonly UserManager<IdentityUser> _userManager;

    public CheckoutController(ApplicationDbContext db, CartService cart, UserManager<IdentityUser> userManager)
    {
        _db = db;
        _cart = cart;
        _userManager = userManager;
    }

    // GET: /Checkout
    public async Task<IActionResult> Index()
    {
        var lines = await _cart.GetLinesAsync();
        if (lines.Count == 0)
        {
            TempData["Error"] = "السلة فارغة.";
            return RedirectToAction("Index", "Cart");
        }

        var user = await _userManager.GetUserAsync(User);
        var vm = new CheckoutViewModel
        {
            Lines = lines,
            Phone = user?.PhoneNumber ?? string.Empty
        };
        return View(vm);
    }

    // POST: /Checkout
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Index(CheckoutViewModel vm)
    {
        var lines = await _cart.GetLinesAsync();
        if (lines.Count == 0)
        {
            TempData["Error"] = "السلة فارغة.";
            return RedirectToAction("Index", "Cart");
        }

        vm.Lines = lines;

        if (vm.PaymentMethod == PaymentMethod.Card)
        {
            ValidateCard(vm);
        }

        if (!ModelState.IsValid)
        {
            return View(vm);
        }

        // ---------- محاكاة بوابة الدفع ----------
        // لا نخزّن بيانات البطاقة. البطاقة التي تنتهي بـ 0000 تُرفض لتجربة حالة الفشل.
        string? paymentReference = null;
        var status = OrderStatus.Pending;

        if (vm.PaymentMethod == PaymentMethod.Card)
        {
            var digits = new string(vm.CardNumber!.Where(char.IsDigit).ToArray());

            if (digits.EndsWith("0000"))
            {
                ModelState.AddModelError(string.Empty, "تم رفض البطاقة من البنك (محاكاة). جرّب بطاقة أخرى.");
                return View(vm);
            }

            paymentReference = $"SIM-{Guid.NewGuid().ToString("N")[..10].ToUpperInvariant()}-{digits[^4..]}";
            status = OrderStatus.Paid;
        }

        // ---------- إنشاء الطلب وخصم المخزون داخل معاملة واحدة ----------
        await using var tx = await _db.Database.BeginTransactionAsync();

        var ids = lines.Select(l => l.Product.Id).ToList();
        var products = await _db.Products
            .Where(p => ids.Contains(p.Id) && p.IsActive)
            .ToListAsync();

        var order = new Order
        {
            UserId = _userManager.GetUserId(User)!,
            CustomerName = vm.FullName.Trim(),
            Phone = vm.Phone.Trim(),
            City = vm.City.Trim(),
            Address = vm.Address.Trim(),
            Notes = string.IsNullOrWhiteSpace(vm.Notes) ? null : vm.Notes.Trim(),
            PaymentMethod = vm.PaymentMethod,
            Status = status,
            PaymentReference = paymentReference
        };

        foreach (var line in lines)
        {
            var product = products.FirstOrDefault(p => p.Id == line.Product.Id);
            if (product == null || product.StockQuantity < line.Quantity)
            {
                await tx.RollbackAsync();
                ModelState.AddModelError(string.Empty,
                    $"عذراً، الكمية المطلوبة من «{line.Product.Name}» لم تعد متوفرة. حدّث السلة وحاول مجدداً.");
                return View(vm);
            }

            product.StockQuantity -= line.Quantity;
            order.Items.Add(new OrderItem
            {
                ProductId = product.Id,
                ProductName = product.Name,
                UnitPrice = product.Price,
                Quantity = line.Quantity
            });
        }

        var subtotal = order.Items.Sum(i => i.LineTotal);
        order.ShippingFee = Pricing.Shipping(subtotal);
        order.Total = subtotal + order.ShippingFee;

        _db.Orders.Add(order);

        try
        {
            await _db.SaveChangesAsync();
            await tx.CommitAsync();
        }
        catch (DbUpdateConcurrencyException)
        {
            await tx.RollbackAsync();
            ModelState.AddModelError(string.Empty, "تغيّر المخزون أثناء إتمام الطلب، يرجى المحاولة مرة أخرى.");
            return View(vm);
        }

        _cart.Clear();
        TempData["Success"] = $"تم استلام طلبك رقم #{order.Id} بنجاح. شكراً لتسوقك معنا!";
        return RedirectToAction("Details", "Orders", new { id = order.Id });
    }

    private void ValidateCard(CheckoutViewModel vm)
    {
        if (string.IsNullOrWhiteSpace(vm.CardHolder))
        {
            ModelState.AddModelError(nameof(vm.CardHolder), "اسم حامل البطاقة مطلوب");
        }

        var digits = new string((vm.CardNumber ?? string.Empty).Where(char.IsDigit).ToArray());
        if (digits.Length < 13 || digits.Length > 19 || !PassesLuhn(digits))
        {
            ModelState.AddModelError(nameof(vm.CardNumber), "رقم البطاقة غير صحيح");
        }

        var expiry = vm.Expiry?.Trim() ?? string.Empty;
        if (!Regex.IsMatch(expiry, @"^(0[1-9]|1[0-2])\/\d{2}$"))
        {
            ModelState.AddModelError(nameof(vm.Expiry), "الصيغة المطلوبة MM/YY");
        }
        else
        {
            var month = int.Parse(expiry[..2], CultureInfo.InvariantCulture);
            var year = 2000 + int.Parse(expiry[3..], CultureInfo.InvariantCulture);
            var lastDay = new DateTime(year, month, DateTime.DaysInMonth(year, month));
            if (lastDay < DateTime.Today)
            {
                ModelState.AddModelError(nameof(vm.Expiry), "البطاقة منتهية الصلاحية");
            }
        }

        if (!Regex.IsMatch(vm.Cvv ?? string.Empty, @"^\d{3,4}$"))
        {
            ModelState.AddModelError(nameof(vm.Cvv), "رمز CVV غير صحيح");
        }
    }

    private static bool PassesLuhn(string digits)
    {
        var sum = 0;
        var alternate = false;

        for (var i = digits.Length - 1; i >= 0; i--)
        {
            var n = digits[i] - '0';
            if (alternate)
            {
                n *= 2;
                if (n > 9)
                {
                    n -= 9;
                }
            }

            sum += n;
            alternate = !alternate;
        }

        return sum % 10 == 0;
    }
}
