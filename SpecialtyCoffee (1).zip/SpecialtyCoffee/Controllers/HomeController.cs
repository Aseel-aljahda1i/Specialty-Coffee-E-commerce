using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SpecialtyCoffee.Data;
using SpecialtyCoffee.Models;

namespace SpecialtyCoffee.Controllers;

public class HomeController : Controller
{
    private readonly ApplicationDbContext _db;

    public HomeController(ApplicationDbContext db)
    {
        _db = db;
    }

    public async Task<IActionResult> Index()
    {
        var featured = await _db.Products
            .AsNoTracking()
            .Where(p => p.IsActive && p.StockQuantity > 0)
            .OrderByDescending(p => p.Rating)
            .ThenByDescending(p => p.RatingCount)
            .Take(4)
            .ToListAsync();

        return View(featured);
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        ViewData["RequestId"] = Activity.Current?.Id ?? HttpContext.TraceIdentifier;
        return View();
    }
}
