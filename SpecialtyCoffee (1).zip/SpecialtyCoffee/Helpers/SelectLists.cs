using Microsoft.AspNetCore.Mvc.Rendering;
using SpecialtyCoffee.Models;

namespace SpecialtyCoffee.Helpers;

public static class SelectLists
{
    public static IEnumerable<SelectListItem> ProductTypes() =>
        Enum.GetValues<ProductType>()
            .Select(t => new SelectListItem(t.ToArabic(), ((int)t).ToString()));

    public static IEnumerable<SelectListItem> OrderStatuses() =>
        Enum.GetValues<OrderStatus>()
            .Select(s => new SelectListItem(s.ToArabic(), ((int)s).ToString()));
}
